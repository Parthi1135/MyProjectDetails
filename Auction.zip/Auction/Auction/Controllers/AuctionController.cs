﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.ViewModels;
using Auction.Models;
using System.Data;

namespace Auction.Controllers
{
    public class AuctionController : Controller
    {
        private AuctionEntities db = new AuctionEntities();
        List<SelectListItem> lstParticipant = new List<SelectListItem>();
        //
        // GET: /Auction/

        public ActionResult Index()
        {
            AuctionVM auct = new AuctionVM();
            auct.lstScheme = db.tblChitSchemes.Where(p => p.ChitSatus != "C").ToList();
            ViewBag.lstParticipant = lstParticipant;
            return View(auct);

        }

        public ActionResult ChitWinners()
        {
            var chitwinners = (from a in db.tblAuctionDetails
                               join p in db.tblParticipants
                               on a.ParticipantID equals p.ParticipantID
                               join c in db.tblChitSchemes
                               on a.ChitID equals c.ChitID
                               select new ChitWinnerVM
                               {
                                   ChitName = c.ChitName,
                                   ParticipantName = p.ParticipantName,
                                   AuctionDate = a.AuctionDate,
                                   AuctionAmount = a.AuctionAmount
                               }).ToList<ChitWinnerVM>().OrderBy(c => c.ChitName);

            return View(chitwinners);

        }

        [HttpPost]
        public ActionResult Index(AuctionVM ModelAuction)
        {
            tblAuctionDetail objAuct = new tblAuctionDetail();
            objAuct.AuctionID = ModelAuction.AuctionID;
            objAuct.ChitID = ModelAuction.ChitID;
            objAuct.ParticipantID = ModelAuction.ParticipantID;
            objAuct.AuctionAmount = ModelAuction.AuctionAmount;
            objAuct.AuctionDate = ModelAuction.AuctionDate;
            objAuct.AuctionStatus = "O";
            db.tblAuctionDetails.Add(objAuct);
            db.SaveChanges();


            var Collection = (from c in db.tblChitSchemes
                              join p in db.tblParticipants
                              on c.ChitID equals p.ChitID
                              where c.ChitID == ModelAuction.ChitID
                              select new
                              {
                                  p.ParticipantID,
                                  c.ChitTotalPerson,
                                  c.ChitTotalMonth
                              }).ToList();

            int AucID = db.tblAuctionDetails.Max(p => p.AuctionID);
            if (AucID != null)
            {
                var autdet = db.tblAuctionDetails.ToList().Where(p => p.AuctionID == AucID);

                if (autdet != null)
                {
                    foreach (var itemaut in autdet)
                    {
                        foreach (var item in Collection)
                        {
                            tblCollection objColl = new tblCollection();
                            objColl.AuctionID = itemaut.AuctionID;
                            objColl.ContributionAmount = (itemaut.AuctionAmount / item.ChitTotalPerson);
                            objColl.ParticipantID = item.ParticipantID;
                            db.tblCollections.Add(objColl);
                            db.SaveChanges();
                        }
                    }
                }
            }
            return RedirectToAction("Index", "Collection");
        }

        public JsonResult GetAuctionDate(int ChitID)
        {
            var AuctDate = (from s in db.tblChitSchemes
                            join a in db.tblAuctionDetails
                            on s.ChitID equals a.ChitID
                            where s.ChitID == ChitID
                            select new { s.ChitStartDate }).ToList();

            dynamic auctiondt = null;

            if (AuctDate.Count > 0)
            {

                var aut = (from s in db.tblChitSchemes
                           join a in db.tblAuctionDetails
                           on s.ChitID equals a.ChitID
                           where s.ChitID == ChitID
                           select new { a.AuctionID }).ToList();

                if (aut.Count > 0)
                {
                    int auctid = aut.Max(p => p.AuctionID);

                    var sdate = (from s in db.tblChitSchemes
                                 join a in db.tblAuctionDetails
                                 on s.ChitID equals a.ChitID
                                 where s.ChitID == ChitID && a.AuctionID == auctid
                                 select new { a.AuctionDate, s.ChitAuctionDateOfMonth }).ToList();
                    if (sdate.Count > 0)
                    {
                        foreach (var item in sdate)
                        {
                            DateTime dtsDate = item.AuctionDate.AddMonths(1);
                            string strDate = dtsDate.Day.ToString();
                            string strMonth = dtsDate.Month.ToString();
                            string strYear = dtsDate.Year.ToString();
                            auctiondt = Convert.ToString(item.ChitAuctionDateOfMonth) + '/' + strMonth + '/' + strYear;
                        }
                    }
                }

            }
            else
            {
                var sdate = (from s in db.tblChitSchemes
                             where s.ChitID == ChitID
                             select new { s.ChitStartDate, s.ChitAuctionDateOfMonth }).ToList();
                if (sdate.Count > 0)
                {
                    foreach (var item in sdate)
                    {
                        string strDate = item.ChitStartDate.Day.ToString();
                        string strMonth = item.ChitStartDate.Month.ToString();
                        string strYear = item.ChitStartDate.Year.ToString();
                        auctiondt = Convert.ToString(item.ChitAuctionDateOfMonth) + '/' + strMonth + '/' + strYear;
                    }
                }
            }
            return Json(auctiondt, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetParticipant(int ChitID)
        {
            var AlreadypartID = (from a in db.tblAuctionDetails
                                 join p in db.tblParticipants
                                 on a.ParticipantID equals p.ParticipantID
                                 where a.ChitID == ChitID
                                 select new { p.ParticipantID, p.ParticipantName }).ToList();
            dynamic participant = null;

            if (AlreadypartID.Count > 0)
            {
                participant = (from a in db.tblParticipants
                               where !(from p in db.tblAuctionDetails
                                       where a.ChitID == ChitID
                                       select p.ParticipantID).Contains(a.ParticipantID) && a.ChitID == ChitID
                               select new { a.ParticipantID, a.ParticipantName }).ToList();
            }
            else
            {
                participant = db.tblParticipants.Where(p => p.ChitID == ChitID).ToList();
            }

            if (participant != null)
            {
                foreach (var item in participant)
                {
                    lstParticipant.Add(new SelectListItem { Text = item.ParticipantName, Value = Convert.ToString(item.ParticipantID) });
                }
            }

            return Json(lstParticipant, JsonRequestBehavior.AllowGet);
        }

        //
        // GET: /Auction/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Auction/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Auction/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Auction/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Auction/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Auction/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Auction/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
