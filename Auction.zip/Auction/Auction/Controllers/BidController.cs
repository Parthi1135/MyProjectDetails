﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.Models;
using Auction.ViewModels;

namespace Auction.Controllers
{
    public class BidController : Controller
    {
        private AuctionEntities db = new AuctionEntities();

        //
        // GET: /Bit/

        public ActionResult Index()
        {
            if (Session["UserName"].ToString().ToLower() != "admin")
            {
                int chitid = Convert.ToInt32(Session["ChitID"].ToString());
                DateTime auctdate = Convert.ToDateTime(Session["AuctionDate"].ToString());

                var lstBids = (from c in db.tblChitSchemes
                               join b in db.tblBids
                               on c.ChitID equals b.ChitID
                               where b.AuctionDate == auctdate
                                && b.ChitID == chitid
                               select new BidVIEWVM
                               {
                                   ChitName = c.ChitName,
                                   ParticipantName = b.ParticipantName,
                                   AuctionDate = b.AuctionDate,
                                   BidAmount = b.BidAmount

                               }).ToList<BidVIEWVM>().OrderBy(p => p.AuctionDate);

                return View(lstBids);
            }
            else
            {
                var lstBids = (from c in db.tblChitSchemes
                               join b in db.tblBids
                               on c.ChitID equals b.ChitID                             
                               select new BidVIEWVM
                               {
                                   ChitName = c.ChitName,
                                   ParticipantName = b.ParticipantName,
                                   AuctionDate = b.AuctionDate,
                                   BidAmount = b.BidAmount

                               }).ToList<BidVIEWVM>().OrderBy(p => p.AuctionDate);

                return View(lstBids);
            }
        }



        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}