﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Auction.Models;
using System.Web.Mvc;
using Auction.ViewModels;

namespace Auction.Controllers
{
    [Authorize(Roles = "Company,Participant")]
    public class HomeController : Controller
    {
        private AuctionEntities db = new AuctionEntities();
        List<SelectListItem> lstAuction = new List<SelectListItem>();

        public ActionResult Index()
        {
            if (Session["UserName"].ToString().ToLower() != "admin")
            {               
                ViewBag.ParticipantName = Session["UserName"];
                BidVM bid = new BidVM();
                bid.lstScheme = db.tblChitSchemes.Where(p => p.ChitSatus != "C").ToList();
                ViewBag.lstAuction = lstAuction;
                return View(bid);
            }
            else
            {
                return RedirectToAction("Index", "Bid");
            }

        }

        [HttpPost]
        public ActionResult Index(BidVM model)
        {
            string partname = Session["UserName"].ToString();

            var partdet = (from p in db.tblParticipants
                           join c in db.tblChitSchemes
                           on p.ChitID equals c.ChitID
                           where p.ParticipantName == partname && p.ChitID == model.ChitID
                           select new { p.ParticipantName }).FirstOrDefault();
            if (partdet == null)
            {
                TempData["Message"] = "You are not part of this chit scheme. Please choose the correct chit scheme!";
                return RedirectToAction("Index");
            }

            tblBid obj = new tblBid();
            obj.AuctionDate = model.AuctionDate;
            obj.BidAmount = model.BidAmount;
            obj.ChitID = model.ChitID;
            obj.ParticipantName = partname;
            Session["AuctionDate"] = model.AuctionDate;
            Session["ChitID"] = model.ChitID;
            db.tblBids.Add(obj);
            db.SaveChanges();
            return RedirectToAction("Index", "Bid");
        }

        public JsonResult GetAuctionDate(int ChitID)
        {
            var AuctDate = (from s in db.tblChitSchemes
                            join a in db.tblAuctionDetails
                            on s.ChitID equals a.ChitID
                            where s.ChitID == ChitID
                            select new { s.ChitStartDate }).ToList();

            dynamic auctiondt = null;

            if (AuctDate.Count > 0)
            {

                var aut = (from s in db.tblChitSchemes
                           join a in db.tblAuctionDetails
                           on s.ChitID equals a.ChitID
                           where s.ChitID == ChitID
                           select new { a.AuctionID }).ToList();

                if (aut.Count > 0)
                {
                    int auctid = aut.Max(p => p.AuctionID);

                    var sdate = (from s in db.tblChitSchemes
                                 join a in db.tblAuctionDetails
                                 on s.ChitID equals a.ChitID
                                 where s.ChitID == ChitID && a.AuctionID == auctid
                                 select new { a.AuctionDate, s.ChitAuctionDateOfMonth }).ToList();
                    if (sdate.Count > 0)
                    {
                        foreach (var item in sdate)
                        {
                            DateTime dtsDate = item.AuctionDate.AddMonths(1);
                            string strDate = dtsDate.Day.ToString();
                            string strMonth = dtsDate.Month.ToString();
                            string strYear = dtsDate.Year.ToString();
                            auctiondt = Convert.ToString(item.ChitAuctionDateOfMonth) + '/' + strMonth + '/' + strYear;
                        }
                    }
                }

            }
            else
            {
                var sdate = (from s in db.tblChitSchemes
                             where s.ChitID == ChitID
                             select new { s.ChitStartDate, s.ChitAuctionDateOfMonth }).ToList();
                if (sdate.Count > 0)
                {
                    foreach (var item in sdate)
                    {
                        string strDate = item.ChitStartDate.Day.ToString();
                        string strMonth = item.ChitStartDate.Month.ToString();
                        string strYear = item.ChitStartDate.Year.ToString();
                        auctiondt = Convert.ToString(item.ChitAuctionDateOfMonth) + '/' + strMonth + '/' + strYear;
                    }
                }
            }
            return Json(auctiondt, JsonRequestBehavior.AllowGet);
        }
    }
}
