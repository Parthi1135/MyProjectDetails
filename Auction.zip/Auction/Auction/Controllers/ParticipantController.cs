﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.Models;
using Auction.ViewModels;

namespace Auction.Controllers
{
    public class ParticipantController : Controller
    {

        private AuctionEntities db = new AuctionEntities();
        //
        // GET: /Participant/

        public ActionResult Index()
        {
            var lstPart = (from p in db.tblParticipants
                           join r in db.tblRolls
                               on p.RollID equals r.RollID
                           join s in db.tblChitSchemes
                               on p.ChitID equals s.ChitID
                           select new ParticipantVM
                            {
                                ParticipantID = p.ParticipantID,
                                ParticipantName = p.ParticipantName,
                                Address = p.Address,
                                Email = p.Email,
                                Mobile = p.Mobile,
                                RollName = r.RollName,
                                ChitName = s.ChitName
                            }).ToList<ParticipantVM>();
            return View(lstPart);
        }

        //
        // GET: /Participant/Create

        public ActionResult Create(int id = 0)
        {
            if (id == 0)
            {
                ParticipantVM part = new ParticipantVM();
                part.lstRoll = db.tblRolls.ToList();
                part.lstScheme = db.tblChitSchemes.ToList();
                TempData["Flag"] = "S";
                TempData.Keep();
                return View(part);
            }
            else
            {
                tblParticipant tblpart = db.tblParticipants.Find(id);
                ParticipantVM part = new ParticipantVM();
                part.lstRoll = db.tblRolls.ToList();
                part.lstScheme = db.tblChitSchemes.ToList();
                part.ParticipantID = tblpart.ParticipantID;
                part.ParticipantName = tblpart.ParticipantName;
                part.Password = tblpart.Password;
                part.Address = tblpart.Address;
                part.Email = tblpart.Email;
                part.Mobile = tblpart.Mobile;
                part.RollID = tblpart.RollID;
                part.ChitID = tblpart.ChitID;
                TempData["Flag"] = "U";
                TempData.Keep();
                return View(part);
            }
        }

        //
        // POST: /Participant/Create

        [HttpPost]
        public ActionResult Create(ParticipantVM model, string partButton)
        {
            try
            {

                if (ModelState.IsValid)
                {                 

                    if (partButton == "Create")
                    {
                        tblParticipant obj = new tblParticipant();
                        obj.ParticipantID = model.ParticipantID;
                        obj.ParticipantName = model.ParticipantName;
                        obj.Password = model.Password;
                        obj.RollID = model.RollID;
                        obj.ChitID = model.ChitID;
                        obj.Address = model.Address;
                        obj.Mobile = model.Mobile;
                        obj.Email = model.Email;
                        db.tblParticipants.Add(obj);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else if (partButton == "Update")
                    {
                        tblParticipant obj = new tblParticipant();
                        obj.ParticipantID = model.ParticipantID;
                        obj.ParticipantName = model.ParticipantName;
                        obj.Password = model.Password;
                        obj.RollID = model.RollID;
                        obj.ChitID = model.ChitID;
                        obj.Address = model.Address;
                        obj.Mobile = model.Mobile;
                        obj.Email = model.Email;
                        db.tblParticipants.Add(obj);
                        db.Entry(obj).State = EntityState.Modified;
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return RedirectToAction("Index");
                    }
                }
                return View(model);
            }
            catch
            {
                return View();
            }
        }

        ////
        //// GET: /Participant/Edit/5

        //public ActionResult Edit(int id)
        //{

        //    return RedirectToAction("Create");
        //}

        //
        // GET: /Participant/Delete/5

        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Participant/Delete/5

        //[HttpPost]
        public ActionResult Delete(int id)
        {
            try
            {
                tblParticipant tblPart = db.tblParticipants.Find(id);
                db.tblParticipants.Remove(tblPart);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
