﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.Models;
using Auction.ViewModels;


namespace Auction.Controllers
{
    public class CollectionController : Controller
    {
        private AuctionEntities db = new AuctionEntities();
        List<SelectListItem> lstParticipant = new List<SelectListItem>();
        List<SelectListItem> lstAuction = new List<SelectListItem>();
        //
        // GET: /Collection/

        public ActionResult Index()
        {
            CollectionVM coll = new CollectionVM();
            coll.lstScheme = db.tblChitSchemes.Where(p => p.ChitSatus != "C").ToList();
            ViewBag.lstParticipant = lstParticipant;
            ViewBag.lstAuction = lstAuction;
            return View(coll);
        }

        public ActionResult CollectionDetails()
        {
            var chitwinners = (from c in db.tblCollections
                               join a in db.tblAuctionDetails
                               on c.AuctionID equals a.AuctionID
                               join p in db.tblParticipants
                               on c.ParticipantID equals p.ParticipantID
                               join s in db.tblChitSchemes
                               on a.ChitID equals s.ChitID
                               where c.CollectionDate != null
                               select new CollectionDetVM
                               {
                                   ChitName = s.ChitName,
                                   ParticipantName = p.ParticipantName,
                                   AuctionDate = a.AuctionDate,
                                   AuctionAmount = a.AuctionAmount,
                                   ContributionAmount = c.ContributionAmount,
                                   PenalityAmount = c.PenalityAmount,
                                   CollectionDate = c.CollectionDate
                               }).ToList<CollectionDetVM>().OrderBy(c => c.ChitName);

            return View(chitwinners);

        }

        [HttpPost]
        public ActionResult Index(CollectionVM CollVM)
        {
            var CollectDet = (from a in db.tblAuctionDetails
                              join c in db.tblCollections
                              on a.AuctionID equals c.AuctionID
                              join s in db.tblChitSchemes
                              on a.ChitID equals s.ChitID
                              join p in db.tblParticipants
                              on c.ParticipantID equals p.ParticipantID
                              where c.AuctionID == CollVM.AuctionID && c.ParticipantID == CollVM.ParticipantID
                              select new { a.AuctionID, c.CollectionID }).FirstOrDefault();

            if (CollectDet != null)
            {
                tblCollection objcoll = new tblCollection();
                objcoll.AuctionID = CollectDet.AuctionID;
                objcoll.CollectionID = CollectDet.CollectionID;
                objcoll.ContributionAmount = CollVM.ContributionAmount;
                objcoll.CollectionDate = CollVM.CollectionDate;
                objcoll.ParticipantID = CollVM.ParticipantID;
                objcoll.PenalityAmount = CollVM.PenalityAmount;
                db.tblCollections.Add(objcoll);
                db.Entry(objcoll).State = EntityState.Modified;
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public JsonResult GetAuction(int ChitID)
        {
            var auction = db.tblAuctionDetails.Where(p => p.ChitID == ChitID).ToList();
            if (auction != null)
            {
                foreach (var item in auction)
                {
                    lstAuction.Add(new SelectListItem { Text = Convert.ToString((item.AuctionDate).ToString("dd/MM/yyyy")), Value = Convert.ToString(item.AuctionID) });
                }
            }

            return Json(lstAuction, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetParticipant(int AuctionID)
        {
            var participant = (from a in db.tblCollections
                               join p in db.tblParticipants
                                on a.ParticipantID equals p.ParticipantID
                               where a.AuctionID == AuctionID && a.CollectionDate == null
                               select new { p.ParticipantID, p.ParticipantName }).ToList();

            if (participant != null)
            {
                foreach (var item in participant)
                {
                    lstParticipant.Add(new SelectListItem { Text = item.ParticipantName, Value = Convert.ToString(item.ParticipantID) });
                }
            }

            return Json(lstParticipant, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCollDetail(int PartID, int AucID)
        {
            var contribAmt = (from a in db.tblCollections
                              where a.ParticipantID == PartID && a.AuctionID == AucID
                              select new { a.ContributionAmount }).FirstOrDefault();

            string strContribAmt = string.Empty;

            if (contribAmt != null)
            {
                strContribAmt = Convert.ToString(contribAmt.ContributionAmount);

            }

            return Json(strContribAmt, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPenalityDetail(int AucID, string CollDate)
        {
            var lstPenality = (from a in db.tblAuctionDetails
                               join s in db.tblChitSchemes
                               on a.ChitID equals s.ChitID
                               where a.AuctionID == AucID
                               select new { s.ChitPenalityAmount, s.ChitPenalityDateOfMonth, a.AuctionDate }).ToList();

            decimal PenalityAmount = 0;

            if (lstPenality != null)
            {
                foreach (var item in lstPenality)
                {
                    string strDate = item.AuctionDate.Day.ToString();
                    string strMonth = item.AuctionDate.Month.ToString();
                    string strYear = item.AuctionDate.Year.ToString();

                    string chkDate = Convert.ToString(item.ChitPenalityDateOfMonth) + '/' + strMonth + '/' + strYear;

                    int j = (Convert.ToDateTime(CollDate) - Convert.ToDateTime(chkDate)).Days;

                    if (j > 0)
                    {
                        PenalityAmount = Convert.ToDecimal(item.ChitPenalityAmount);
                    }
                    else
                    {
                        PenalityAmount = 0;
                    }
                }
            }

            return Json(PenalityAmount, JsonRequestBehavior.AllowGet);
        }


        //
        // GET: /Collection/Details/5

        public ActionResult Details(int id = 0)
        {
            tblCollection tblcollection = db.tblCollections.Find(id);
            if (tblcollection == null)
            {
                return HttpNotFound();
            }
            return View(tblcollection);
        }

        //
        // GET: /Collection/Create

        public ActionResult Create()
        {
            ViewBag.AuctionID = new SelectList(db.tblAuctionDetails, "AuctionID", "AuctionStatus");
            ViewBag.ParticipantID = new SelectList(db.tblParticipants, "ParticipantID", "Password");
            return View();
        }

        //
        // POST: /Collection/Create

        [HttpPost]
        public ActionResult Create(tblCollection tblcollection)
        {
            if (ModelState.IsValid)
            {
                db.tblCollections.Add(tblcollection);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.AuctionID = new SelectList(db.tblAuctionDetails, "AuctionID", "AuctionStatus", tblcollection.AuctionID);
            ViewBag.ParticipantID = new SelectList(db.tblParticipants, "ParticipantID", "Password", tblcollection.ParticipantID);
            return View(tblcollection);
        }

        //
        // GET: /Collection/Edit/5

        public ActionResult Edit(int id = 0)
        {
            tblCollection tblcollection = db.tblCollections.Find(id);
            if (tblcollection == null)
            {
                return HttpNotFound();
            }
            ViewBag.AuctionID = new SelectList(db.tblAuctionDetails, "AuctionID", "AuctionStatus", tblcollection.AuctionID);
            ViewBag.ParticipantID = new SelectList(db.tblParticipants, "ParticipantID", "Password", tblcollection.ParticipantID);
            return View(tblcollection);
        }

        //
        // POST: /Collection/Edit/5

        [HttpPost]
        public ActionResult Edit(tblCollection tblcollection)
        {
            //if (ModelState.IsValid)
            //{
            db.Entry(tblcollection).State = EntityState.Modified;
            db.SaveChanges();

            //When last person pay last due
            //tblChitScheme objChit = db.tblChitSchemes.Find(ModelAuction.ChitID);
            //objChit.ChitSatus = "C"; //Completed

            //db.Entry(objChit).State = EntityState.Modified;
            //db.SaveChanges();


            return RedirectToAction("Index");
            //}
            //ViewBag.AuctionID = new SelectList(db.tblAuctionDetails, "AuctionID", "AuctionStatus", tblcollection.AuctionID);
            //ViewBag.ParticipantID = new SelectList(db.tblParticipants, "ParticipantID", "Password", tblcollection.ParticipantID);
            //return View(tblcollection);
        }

        //
        // GET: /Collection/Delete/5

        public ActionResult Delete(int id = 0)
        {
            tblCollection tblcollection = db.tblCollections.Find(id);
            if (tblcollection == null)
            {
                return HttpNotFound();
            }
            return View(tblcollection);
        }

        //
        // POST: /Collection/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            tblCollection tblcollection = db.tblCollections.Find(id);
            db.tblCollections.Remove(tblcollection);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}