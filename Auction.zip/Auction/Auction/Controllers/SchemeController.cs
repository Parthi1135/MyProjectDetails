﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.Models;

namespace Auction.Controllers
{
    public class SchemeController : Controller
    {
        private AuctionEntities db = new AuctionEntities();

        //
        // GET: /Scheme/

        public ActionResult Index()
        {
            ViewBag.SideMenuStype = "S";
            return View(db.tblChitSchemes.ToList());
        }

        //
        // GET: /Scheme/Details/5

        //public ActionResult Details(int id = 0)
        //{
        //    tblChitScheme tblchitscheme = db.tblChitSchemes.Find(id);
        //    if (tblchitscheme == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(tblchitscheme);
        //}

        //
        // GET: /Scheme/Create

        public ActionResult Create()
        {
            return RedirectToAction("Edit", new { flag = "Y" });
        }

        //
        // POST: /Scheme/Create

        [HttpPost]
        public ActionResult Create(tblChitScheme tblchitscheme)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.tblChitSchemes.Add(tblchitscheme);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(tblchitscheme);
            }
            catch (Exception)
            {
                return View("Shared/Error.cshtml");
            }
        }

        //
        // GET: /Scheme/Edit/5

        public ActionResult Edit(int id = 0, string flag = "N")
        {
            Session["FLAG"] = flag;
            tblChitScheme tblchitscheme = db.tblChitSchemes.Find(id);
            //string selected = (from chit in db.tblChitSchemes
            //                   where chit.ChitID == id
            //                   select chit.ChitSatus).First();
            //string selected = tblchitscheme.ChitSatus;
            //if (tblchitscheme == null)
            //{
            //    return HttpNotFound();
            //}            
            return View(tblchitscheme);
        }

        //
        // POST: /Scheme/Edit/5

        [HttpPost]
        public ActionResult Edit(tblChitScheme tblchitscheme, string shemebutton)
        {
            if (ModelState.IsValid)
            {
                if (shemebutton == "Create")
                {
                    db.tblChitSchemes.Add(tblchitscheme);
                    db.SaveChanges();
                }
                else
                {
                    db.Entry(tblchitscheme).State = EntityState.Modified;
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            return View(tblchitscheme);
        }

        //
        // GET: /Scheme/Delete/5

        public ActionResult Delete(int id = 0)
        {
            tblChitScheme tblchitscheme = db.tblChitSchemes.Find(id);
            if (tblchitscheme == null)
            {
                return HttpNotFound();
            }
            if (tblchitscheme.ChitSatus == "O")
                ViewBag.Status = "Open";
            else
                ViewBag.Status = "Close";

            return View(tblchitscheme);
        }

        //
        // POST: /Scheme/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            tblChitScheme tblchitscheme = db.tblChitSchemes.Find(id);
            db.tblChitSchemes.Remove(tblchitscheme);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}