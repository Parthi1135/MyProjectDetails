﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.ViewModels;
using Auction.Models;
using System.Web.Security;

namespace Auction.Controllers
{

    public class UserController : Controller
    {
        private AuctionEntities db = new AuctionEntities();

        #region  "Login"
        //
        // GET: /User/
        [AllowAnonymous]
        public ActionResult Login()
        {
            UserVM user = new UserVM();
            user.lstRolls = db.tblRolls.ToList();
            return View(user);
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserVM model)
        {
            if (ModelState.IsValid)
            {
                dynamic userName = null;
                if (model.RollID == 1)
                {
                    userName = (from c in db.tblCompanies
                                join r in db.tblRolls
                                on c.RollID equals r.RollID
                                where c.CompanyName == model.UserName && c.Password == model.Password
                                select new { c.CompanyName }).SingleOrDefault();
                    Session["UserType"] = "C";
                }

                if (model.RollID == 2)
                {
                    userName = db.tblParticipants.Where(p => p.ParticipantName == model.UserName && p.Password == model.Password).Join(db.tblRolls,
                         p => p.RollID, r => r.RollID, (p, r) => new { p.ParticipantName }).FirstOrDefault();
                    Session["UserType"] = "P";
                }

                if (userName != null)
                {
                    Session["UserName"] = model.UserName;
                    FormsAuthentication.SetAuthCookie(model.UserName, model.RememberMe);                    
                    return RedirectToAction("Index", "Home");
                }
                else
                {                    
                    ModelState.AddModelError("", "The user name or password provided is incorrect.");
                }
            }
            model.lstRolls = db.tblRolls.ToList();
            //if (!ModelState.IsValid)
            //    return View(model);
            return View(model);

        }

        [AllowAnonymous]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }
        #endregion
    }
}
