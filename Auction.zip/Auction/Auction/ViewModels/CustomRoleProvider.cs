﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using Auction.Models;

namespace Auction.ViewModels
{
    public class CustomRoleProvider : RoleProvider
    {
        private AuctionEntities db = new AuctionEntities();

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override string ApplicationName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override void CreateRole(string roleName)
        {

            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            var Rolls = db.tblRolls.Select(x => x.RollName);
            return Rolls.ToArray<string>();
        }

        public override string[] GetRolesForUser(string username)
        {
            var CompUser = (from c in db.tblCompanies
                            join r in db.tblRolls
                            on c.RollID equals r.RollID
                            where c.CompanyName == username
                            select new { r.RollName, r.RollID }).FirstOrDefault();

            if (CompUser == null)
            {
                var PartData = (from p in db.tblParticipants
                                join r in db.tblRolls
                                 on p.RollID equals r.RollID
                                where p.ParticipantName == username
                                select new { r.RollName }).ToArray();
                if (PartData != null)
                {
                    return new string[] { PartData[0].RollName };
                }
            }

            return new string[] { CompUser.RollName };
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            throw new NotImplementedException();
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }
    }
}