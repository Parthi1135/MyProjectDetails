﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Auction.Models;

namespace Auction.ViewModels
{
    public class BidVM
    {
        public List<tblChitScheme> lstScheme { get; set; }
       

        [Required(ErrorMessage = "* Required")]
        public int ChitID { get; set; }
        
        [Required(ErrorMessage = "* Required")]
        public DateTime AuctionDate { get; set; }
       
        [Required(ErrorMessage = "* Required")]
        [DisplayName("Bid Amount")]
        public decimal BidAmount { get; set; }
    }

    public class BidVIEWVM
    {
        [DisplayName("Participant Name")]
        public string ParticipantName { get; set; }

        
        [DisplayName("Chit Scheme Name")]
        public string ChitName { get; set; }

        [DisplayName("Auction Date")]
        public DateTime AuctionDate { get; set; }


        [DisplayName("Bid Amount")]
        public decimal BidAmount { get; set; }
    }
}