﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Auction.ViewModels
{
    public class ChitWinnerVM
    {
        [DisplayName("Participant Name")]
        public string ParticipantName { get; set; }


        [DisplayName("Chit Scheme Name")]
        public string ChitName { get; set; }

        [DisplayName("Auction Amount")]
        public decimal AuctionAmount { get; set; }


        [DisplayName("Auction Date")]
        public DateTime AuctionDate { get; set; }


    }

   
}