﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Auction.Models;

namespace Auction.ViewModels
{
    public class ParticipantVM
    {
        //public List<tblParticipant> lstParticipant { get; set; }
        public List<tblRoll> lstRoll { get; set; }
        public List<tblChitScheme> lstScheme { get; set; }
                
        public int ParticipantID { get; set; }
        
        [Required(ErrorMessage = "* Required")]
        public int RollID { get; set; }
        
        [Required(ErrorMessage = "* Required")]
        public int ChitID { get; set; }
        //public SelectList ChitLst { get; set; }
        //public SelectList RollLst { get; set; }
        
        [Required(ErrorMessage="* Required")]
        [DisplayName("Participant Name")]
        public string ParticipantName { get; set; }
                
        [DisplayName("Roll Name")]
        public string RollName { get; set; }
                
        [DisplayName("Chit Scheme Name")]
        public string ChitName { get; set; }

        [Required(ErrorMessage = "* Required")]
        public string Password { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
                      
        [RegularExpression("[0-9]*", ErrorMessage = "Invalid Character")]
        public string Mobile { get; set; }
    }
}