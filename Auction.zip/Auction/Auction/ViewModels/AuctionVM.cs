﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Auction.Models;

namespace Auction.ViewModels
{
    public class AuctionVM
    {
        public List<tblChitScheme> lstScheme { get; set; }
        public List<tblParticipant> lstParticipant { get; set; }

        public int AuctionID { get; set; }

        [Required(ErrorMessage = "* Required")]
        public int ChitID { get; set; }

        [DisplayName("Chit Name")]
        public string ChitName { get; set; }

        [Required(ErrorMessage = "* Required")]
        public int ParticipantID { get; set; }

        [DisplayName("Participant Name")]
        public int ParticipantName { get; set; }

        [Required(ErrorMessage = "* Required")]
        [DisplayName("Auction Amount")]
        public decimal AuctionAmount { get; set; }

        [Required(ErrorMessage = "* Required")]
        [DisplayName("Auction Date")]
        public DateTime AuctionDate { get; set; }

        [Required(ErrorMessage = "* Required")]
        [DisplayName("Status")]
        public string AuctionStatus { get; set; }
    }
}