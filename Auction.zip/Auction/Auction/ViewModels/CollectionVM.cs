﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Auction.Models;

namespace Auction.ViewModels
{
    public class CollectionVM
    {
        public List<tblChitScheme> lstScheme { get; set; }
        public List<tblParticipant> lstParticipant { get; set; }
        public List<tblAuctionDetail> lstAuction { get; set; }

        public int CollectionID { get; set; }

        [Required(ErrorMessage = "* Required")]
        public int ChitID { get; set; }

        [Required(ErrorMessage = "* Required")]
        public int ParticipantID { get; set; }

        [Required(ErrorMessage = "* Required")]
        public int AuctionID { get; set; }
        
        [Required(ErrorMessage = "* Required")]
        [DisplayName("Contribution Amount")]
        public decimal ContributionAmount { get; set; }
        
        [Required(ErrorMessage = "* Required")]
        [DisplayName("Collection Date")]
        public Nullable<System.DateTime> CollectionDate { get; set; }
                
        [DisplayName("Penality Amount")]
        public Nullable<decimal> PenalityAmount { get; set; }
    }
}