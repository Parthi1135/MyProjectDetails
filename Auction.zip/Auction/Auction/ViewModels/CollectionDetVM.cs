﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Auction.ViewModels
{
    public class CollectionDetVM
    {

        [DisplayName("Chit Scheme Name")]
        public string ChitName { get; set; }

        [DisplayName("Participant Name")]
        public string ParticipantName { get; set; }

        [DisplayName("Contribution Amount")]
        public decimal ContributionAmount { get; set; }

        [DisplayName("Auction Amount")]
        public decimal AuctionAmount { get; set; }

        [DisplayName("Auction Date")]
        public DateTime AuctionDate { get; set; }

        [DisplayName("Collection Date")]
        public Nullable<System.DateTime> CollectionDate { get; set; }

        [DisplayName("Penality Date")]
        public Nullable<decimal> PenalityAmount { get; set; }

    }
}