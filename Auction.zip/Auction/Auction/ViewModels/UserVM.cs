﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Web;
using Auction.Models;

namespace Auction.ViewModels
{
    public class UserVM
    {       
        [Required(ErrorMessage = "User Name Required")]
        [MaxLength(500, ErrorMessage = "User Name Length Should be less than 500.")]
        [RegularExpression("[A-Za-z0-9 ]*", ErrorMessage = "Invalid Character")]//allow empty string
        public string UserName { get; set; }
        
        [Required(ErrorMessage = "User Password Required")]
        [MaxLength(100, ErrorMessage = "User Password Should be less than 100.")]
        [RegularExpression("[A-Za-z0-9]+", ErrorMessage = "Invalid Character")]//will not allow empty string
        public string Password { get; set; }
        
        public bool RememberMe { get; set; }

        [Required(ErrorMessage = "User Roll Required")]        
        public int RollID { get; set; }

        public virtual tblRoll Rolls { get; set; }
        public virtual ICollection<tblRoll> lstRolls { get; set; }

    }
}