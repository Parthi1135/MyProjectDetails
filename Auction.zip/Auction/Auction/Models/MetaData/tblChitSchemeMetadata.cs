﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Auction.Models
{
    [MetadataType(typeof(tblChitSchemeMetadata))]
    public partial class tblChitScheme
    {
    }

    public class tblChitSchemeMetadata
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ChitID { get; set; }

        [Required(ErrorMessage = "Chit Name should not be empty!")]
        [Display(Name = "Chit Name")]
        [StringLength(500, ErrorMessage = "Name must be less than 500 characters!")]
        public string ChitName { get; set; }

        [Display(Name = "Amount")]
        public decimal ChitAmount { get; set; }

        [Display(Name = "Total Person")]
        public int ChitTotalPerson { get; set; }

        [Display(Name = "Total Month")]
        public int ChitTotalMonth { get; set; }

        [Display(Name = "Auction Per Year")]
        public int ChitAuctionPerYear { get; set; }

        [Display(Name = "Start Date")]
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public System.DateTime ChitStartDate { get; set; }

        [Display(Name = "End Date")]
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public System.DateTime ChitEndDate { get; set; }
        [Required(ErrorMessage="Please Select Chit Status")]
        [Display(Name = "Status")]
        public string ChitSatus { get; set; }
        [Required(ErrorMessage = "Enter Penality Amount")]
        [Display(Name = "Penality Amount")]
        public Nullable<decimal> ChitPenalityAmount { get; set; }
        [Required(ErrorMessage = "Choose Auction Date")]
        [Display(Name = "Auction Date Of The Month")]
        public Nullable<int> ChitAuctionDateOfMonth { get; set; }
        [Required(ErrorMessage = "Choose Penality Date")]
        [Display(Name = "Penality Date of the Month")]
        public Nullable<int> ChitPenalityDateOfMonth { get; set; }
    
    }
}