﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Auction.Models.MetaData
{
    [MetadataType(typeof(tblCollectionMetadata))]
    public partial class tblCollection
    {
    }

    public class tblCollectionMetadata
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int CollectionID { get; set; }
    }
}