﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Auction.Models.MetaData
{
  
    [MetadataType(typeof(tblBidMetadata))]
    public partial class tblBid
    {
    }

    public class tblBidMetadata
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int BidID { get; set; }
    }
}