﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Auction.Models.MetaData
{
    [MetadataType(typeof(tblAuctionDetailMetadata))]
    public partial class tblAuctionDetail
    {
    }

    public class tblAuctionDetailMetadata
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int AuctionID { get; set; }
    }
}