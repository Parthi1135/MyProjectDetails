﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using S2M.Models;

namespace S2M.Controllers
{
    public class CompanyController : Controller
    {
        private S2MEntities db = new S2MEntities();

        //
        // GET: /Company/

        public ActionResult Index()
        {
            return View(db.tblCompanies.ToList());
        }

        //
        // GET: /Company/Details/5

        public ActionResult Details(int id = 0)
        {
            tblCompany tblcompany = db.tblCompanies.Find(id);
            if (tblcompany == null)
            {
                return HttpNotFound();
            }
            return View(tblcompany);
        }

        //
        // GET: /Company/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Company/Create

        [HttpPost]
        public ActionResult Create(tblCompany tblcompany)
        {
            if (ModelState.IsValid)
            {
                db.tblCompanies.Add(tblcompany);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tblcompany);
        }

        //
        // GET: /Company/Edit/5

        public ActionResult Edit(int id = 0)
        {
            tblCompany tblcompany = db.tblCompanies.Find(id);
            if (tblcompany == null)
            {
                return HttpNotFound();
            }
            return View(tblcompany);
        }

        //
        // POST: /Company/Edit/5

        [HttpPost]
        public ActionResult Edit(tblCompany tblcompany)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tblcompany).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tblcompany);
        }

        //
        // GET: /Company/Delete/5

        public ActionResult Delete(int id = 0)
        {
            tblCompany tblcompany = db.tblCompanies.Find(id);
            if (tblcompany == null)
            {
                return HttpNotFound();
            }
            return View(tblcompany);
        }

        //
        // POST: /Company/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            tblCompany tblcompany = db.tblCompanies.Find(id);
            db.tblCompanies.Remove(tblcompany);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}