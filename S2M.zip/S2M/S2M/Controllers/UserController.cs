﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using S2M.Models;

namespace S2M.Controllers
{
    public class UserController : Controller
    {
        private S2MEntities db = new S2MEntities();

        //
        // GET: /User/

        public ActionResult Index()
        {
            var tblusers = db.tblUsers.Include(t => t.tblCompany).Include(t => t.tblRoll);
            return View(tblusers.ToList());
        }

        //
        // GET: /User/Details/5

        public ActionResult Details(int id = 0)
        {
            tblUser tbluser = db.tblUsers.Find(id);
            if (tbluser == null)
            {
                return HttpNotFound();
            }
            return View(tbluser);
        }

        //
        // GET: /User/Create

        public ActionResult Create()
        {
            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName");
            ViewBag.RollID = new SelectList(db.tblRolls, "RollID", "RollName");
            return View();
        }

        //
        // POST: /User/Create

        [HttpPost]
        public ActionResult Create(tblUser tbluser)
        {
            if (ModelState.IsValid)
            {
                db.tblUsers.Add(tbluser);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbluser.CompID);
            ViewBag.RollID = new SelectList(db.tblRolls, "RollID", "RollName", tbluser.RollID);
            return View(tbluser);
        }

        //
        // GET: /User/Edit/5

        public ActionResult Edit(int id = 0)
        {
            tblUser tbluser = db.tblUsers.Find(id);
            if (tbluser == null)
            {
                return HttpNotFound();
            }
            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbluser.CompID);
            ViewBag.RollID = new SelectList(db.tblRolls, "RollID", "RollName", tbluser.RollID);
            return View(tbluser);
        }

        //
        // POST: /User/Edit/5

        [HttpPost]
        public ActionResult Edit(tblUser tbluser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbluser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbluser.CompID);
            ViewBag.RollID = new SelectList(db.tblRolls, "RollID", "RollName", tbluser.RollID);
            return View(tbluser);
        }

        //
        // GET: /User/Delete/5

        public ActionResult Delete(int id = 0)
        {
            tblUser tbluser = db.tblUsers.Find(id);
            if (tbluser == null)
            {
                return HttpNotFound();
            }
            return View(tbluser);
        }

        //
        // POST: /User/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            tblUser tbluser = db.tblUsers.Find(id);
            db.tblUsers.Remove(tbluser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}