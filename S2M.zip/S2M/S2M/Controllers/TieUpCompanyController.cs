﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using S2M.Models;

namespace S2M.Controllers
{
    public class TieUpCompanyController : Controller
    {
        private S2MEntities db = new S2MEntities();

        //
        // GET: /TieUpCompany/

        public ActionResult Index()
        {
            var tbltieupcompanies = db.tblTieUpCompanies.Include(t => t.tblCompany);
            return View(tbltieupcompanies.ToList());
        }

        //
        // GET: /TieUpCompany/Details/5

        public ActionResult Details(int id = 0)
        {
            tblTieUpCompany tbltieupcompany = db.tblTieUpCompanies.Find(id);
            if (tbltieupcompany == null)
            {
                return HttpNotFound();
            }
            return View(tbltieupcompany);
        }

        //
        // GET: /TieUpCompany/Create

        public ActionResult Create()
        {
            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName");
            ViewBag.TieUpCompID = new SelectList(db.tblCompanies, "CompID", "CompName");
            return View();
        }

        //
        // POST: /TieUpCompany/Create

        [HttpPost]
        public ActionResult Create(tblTieUpCompany tbltieupcompany)
        {
            if (ModelState.IsValid)
            {                
                db.tblTieUpCompanies.Add(tbltieupcompany);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbltieupcompany.CompID);
            ViewBag.TieUpCompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbltieupcompany.CompID);
            return View(tbltieupcompany);
        }

        //
        // GET: /TieUpCompany/Edit/5

        public ActionResult Edit(int id = 0)
        {
            tblTieUpCompany tbltieupcompany = db.tblTieUpCompanies.Find(id);
            if (tbltieupcompany == null)
            {
                return HttpNotFound();
            }
            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbltieupcompany.CompID);
            return View(tbltieupcompany);
        }

        //
        // POST: /TieUpCompany/Edit/5

        [HttpPost]
        public ActionResult Edit(tblTieUpCompany tbltieupcompany)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbltieupcompany).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CompID = new SelectList(db.tblCompanies, "CompID", "CompName", tbltieupcompany.CompID);
            return View(tbltieupcompany);
        }

        //
        // GET: /TieUpCompany/Delete/5

        public ActionResult Delete(int id = 0)
        {
            tblTieUpCompany tbltieupcompany = db.tblTieUpCompanies.Find(id);
            if (tbltieupcompany == null)
            {
                return HttpNotFound();
            }
            return View(tbltieupcompany);
        }

        //
        // POST: /TieUpCompany/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            tblTieUpCompany tbltieupcompany = db.tblTieUpCompanies.Find(id);
            db.tblTieUpCompanies.Remove(tbltieupcompany);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}